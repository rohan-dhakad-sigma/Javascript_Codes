<?php

// $html = "";??
$html = $_POST['rohan'];

echo $html;
?>